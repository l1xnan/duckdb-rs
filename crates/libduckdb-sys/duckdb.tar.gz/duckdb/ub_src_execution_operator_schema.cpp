#include "src/execution/operator/schema/physical_alter.cpp"

#include "src/execution/operator/schema/physical_attach.cpp"

#include "src/execution/operator/schema/physical_create_art_index.cpp"

#include "src/execution/operator/schema/physical_create_schema.cpp"

#include "src/execution/operator/schema/physical_create_type.cpp"

#include "src/execution/operator/schema/physical_create_sequence.cpp"

#include "src/execution/operator/schema/physical_create_table.cpp"

#include "src/execution/operator/schema/physical_create_view.cpp"

#include "src/execution/operator/schema/physical_create_function.cpp"

#include "src/execution/operator/schema/physical_detach.cpp"

#include "src/execution/operator/schema/physical_drop.cpp"

