#include "src/common/multi_file/base_file_reader.cpp"

#include "src/common/multi_file/multi_file_function.cpp"

#include "src/common/multi_file/multi_file_list.cpp"

#include "src/common/multi_file/multi_file_reader.cpp"

#include "src/common/multi_file/multi_file_column_mapper.cpp"

#include "src/common/multi_file/union_by_name.cpp"

