#include "src/execution/operator/persistent/csv_rejects_table.cpp"

#include "src/execution/operator/persistent/physical_batch_copy_to_file.cpp"

#include "src/execution/operator/persistent/physical_batch_insert.cpp"

#include "src/execution/operator/persistent/physical_copy_database.cpp"

#include "src/execution/operator/persistent/physical_copy_to_file.cpp"

#include "src/execution/operator/persistent/physical_delete.cpp"

#include "src/execution/operator/persistent/physical_export.cpp"

#include "src/execution/operator/persistent/physical_insert.cpp"

#include "src/execution/operator/persistent/physical_update.cpp"

