#include "extension/parquet/decoder/byte_stream_split_decoder.cpp"

#include "extension/parquet/decoder/delta_binary_packed_decoder.cpp"

#include "extension/parquet/decoder/delta_byte_array_decoder.cpp"

#include "extension/parquet/decoder/delta_length_byte_array_decoder.cpp"

#include "extension/parquet/decoder/dictionary_decoder.cpp"

#include "extension/parquet/decoder/rle_decoder.cpp"

