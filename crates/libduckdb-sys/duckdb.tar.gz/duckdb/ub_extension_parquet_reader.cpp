#include "extension/parquet/reader/decimal_column_reader.cpp"

#include "extension/parquet/reader/expression_column_reader.cpp"

#include "extension/parquet/reader/list_column_reader.cpp"

#include "extension/parquet/reader/row_number_column_reader.cpp"

#include "extension/parquet/reader/string_column_reader.cpp"

#include "extension/parquet/reader/struct_column_reader.cpp"

