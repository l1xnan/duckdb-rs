#include "extension/core_functions/scalar/debug/vector_type.cpp"

