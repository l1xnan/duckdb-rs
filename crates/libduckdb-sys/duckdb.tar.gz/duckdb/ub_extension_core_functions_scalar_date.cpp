#include "extension/core_functions/scalar/date/current.cpp"

#include "extension/core_functions/scalar/date/age.cpp"

#include "extension/core_functions/scalar/date/date_diff.cpp"

#include "extension/core_functions/scalar/date/date_sub.cpp"

#include "extension/core_functions/scalar/date/to_interval.cpp"

#include "extension/core_functions/scalar/date/time_bucket.cpp"

#include "extension/core_functions/scalar/date/date_trunc.cpp"

#include "extension/core_functions/scalar/date/epoch.cpp"

#include "extension/core_functions/scalar/date/date_part.cpp"

#include "extension/core_functions/scalar/date/make_date.cpp"

