#include "extension/core_functions/scalar/blob/base64.cpp"

#include "extension/core_functions/scalar/blob/encode.cpp"

