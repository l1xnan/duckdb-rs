#include "extension/json/json_functions/copy_json.cpp"

#include "extension/json/json_functions/json_array_length.cpp"

#include "extension/json/json_functions/json_contains.cpp"

#include "extension/json/json_functions/json_exists.cpp"

#include "extension/json/json_functions/json_extract.cpp"

#include "extension/json/json_functions/json_keys.cpp"

#include "extension/json/json_functions/json_merge_patch.cpp"

#include "extension/json/json_functions/json_pretty.cpp"

#include "extension/json/json_functions/json_structure.cpp"

#include "extension/json/json_functions/json_transform.cpp"

#include "extension/json/json_functions/json_create.cpp"

#include "extension/json/json_functions/json_type.cpp"

#include "extension/json/json_functions/json_valid.cpp"

#include "extension/json/json_functions/json_value.cpp"

#include "extension/json/json_functions/json_serialize_plan.cpp"

#include "extension/json/json_functions/json_serialize_sql.cpp"

#include "extension/json/json_functions/read_json.cpp"

#include "extension/json/json_functions/read_json_objects.cpp"

