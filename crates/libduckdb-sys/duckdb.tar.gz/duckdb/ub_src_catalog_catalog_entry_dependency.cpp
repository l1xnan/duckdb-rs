#include "src/catalog/catalog_entry/dependency/dependency_entry.cpp"

#include "src/catalog/catalog_entry/dependency/dependency_subject_entry.cpp"

#include "src/catalog/catalog_entry/dependency/dependency_dependent_entry.cpp"

